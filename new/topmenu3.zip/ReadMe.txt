Readme file creation date: Nov 28th, 2004

Instructions for installing Top Navigational Bar 3 v3.5, available at http://www.dynamicdrive.com

Three steps to installing this script:

Step 1) Add the below to the <HEAD> section of your page:

<script type="text/javascript" language="javascript" src="sniffer.js">

/***********************************************
* Top Navigational Bar III v3.5 (By BrotherCake- brothercake.com)
* Exclusive permission by Dynamicdrive.com to include script in archive
* For this and 100's more DHTML scripts, visit http://www.dynamicdrive.com/
* This notice MUST stay intact for legal use
***********************************************/

</script>
<script type="text/javascript" language="javascript1.2" src="custom.js"></script>
<script type="text/javascript" language="javascript1.2" src="style.js"></script>

Step 2) Add the below to the <BODY> section of your page, at the VERY end (right above the </BODY> tag). It is very important that the below be added at the end of the document:

<script type="text/javascript" language="javascript1.2" src="menu.js"></script>

Step 3) Finally, upload all the .js files contained inside this zip into your webpage directory where the menu resides in.

You're done!

Note: All configurations to this script should be done inside custom.js. Open up the file using any text editor, and change the menu items to your own.

For a complete description of the variables contained inside custom.js, see: http://www.brothercake.com/topnavIII/

For a good text editor program to edit custom.js: http://download.com.com/3120-20-0.html?qt=text+editor&tg=dl-2001

Enjoy!

Dynamicdrive.com