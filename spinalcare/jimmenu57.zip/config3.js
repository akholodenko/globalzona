function init()
{
	menus[0] = new menu(20, "horizontal", 260, 20, 0, -2, "img:images/background1.jpg", "img:images/background2.jpg", "Arial,Helvetica", 9, "bold", 
		"bold", "white", "white", 0, "white", 2, "rollover:images/tri-down1.gif:images/tri-down2.gif", false, false, true, false, 0, true, 4, 4, "gray");
	menus[0].addItem("menu.html", "_blank", 100, "center", "Item 1", 0);
	menus[0].addItem("#", "", 100, "center", "Item 2", 1);
	menus[0].addItem("#", "", 100, "center", "Item 3", 2);
	menus[0].addItem("#", "", 100, "center", "Item 4", 0);
	menus[0].addItem("#", "", 100, "center", "Item 5", 0);
	menus[0].floatMenu(1024, 768, 10, 0);
	
	menus[1] = new menu(100, "vertical", 0, 0, -5, -5, "white", "royalblue", "Arial,Helvetica", 9, "", 
		"bold", "black", "white", 1, "black", 2, 187, false, false, false, false, 0, true, 4, 4, "gray");
	menus[1].addItem("#", "", 22, "center", "Item 1_1", 0);
	menus[1].addSeparator(1, "black");
	menus[1].addItem("#", "", 22, "center", "Item 1_2", 0);
	menus[1].addItem("#", "", 22, "center", "Item 1_3", 0);
	menus[1].addSeparator(1, "black");
	menus[1].addItem("#", "", 22, "center", "Item 1_4", 3);

	menus[2] = new menu(22, "horizontal", 0, 0, 0, -2, "white", "royalblue", "Arial,Helvetica", 9, "", 
		"bold", "black", "white", 1, "black", 2, "rollover:images/tri-down1.gif:images/tri-down2.gif", false, true, false, false, 0, true, 4, 4, "gray");
	menus[2].addItem("#", "", 100, "left", "Item 2_1", 0);
	menus[2].addItem("#", "", 100, "left", "Item 2_2", 4);
	menus[2].addItem("#", "", 100, "left", "Item 2_3", 0);
	menus[2].addItem("http://www.yahoo.com", "", 100, "left", "Item 2_4", 0);

	menus[3] = new menu(100, "vertical", 0, 0, 0, 0, "white", "royalblue", "Arial,Helvetica", 9, "", 
		"bold", "black", "white", 1, "black", 2, 0, false, true, false, false, 0, true, 4, 4, "gray");
	menus[3].addItem("#", "", 22, "left", "Item 3_1", 0);
	menus[3].addItem("javascript:alert('PopMenu v5.5')", "", 22, "left", "Item 3_2", 0);

	menus[4] = new menu(100, "vertical", 0, 0, -5, -5, "white", "royalblue", "Arial,Helvetica", 9, "", 
		"bold", "black", "white", 1, "black", 2, "rollover:images/tri-right1.gif:images/tri-right2.gif", false, true, false, false, 0, true, 4, 4, "gray");
	menus[4].addItem("#", "", 22, "left", "Item 4_1", 0);
	menus[4].addItem("#", "", 22, "left", "Item 4_2", 0);
	menus[4].addItem("#", "", 22, "left", "Item 4_3", 5);

	menus[5] = new menu(100, "vertical", 0, 0, 0, 0, "white", "royalblue", "Arial,Helvetica", 9, "", 
		"bold", "black", "white", 1, "black", 2, 0, false, true, false, false, 0, true, 4, 4, "gray");
	menus[5].addItem("#", "", 22, "left", "Item 5_1", 0);
	menus[5].addItem("#", "", 22, "left", "Item 5_2", 0);
	menus[5].addItem("#", "", 22, "left", "Item 5_3", 0);
}